import json

def lambda_handler(event, context):
    print("lambda started.  event:{}".format(event))
